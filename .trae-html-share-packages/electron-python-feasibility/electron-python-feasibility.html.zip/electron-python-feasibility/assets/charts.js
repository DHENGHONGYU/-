/**
 * charts.js — FinSightV9 方案B 可行性分析报告图表
 *
 * 依赖: echarts.min.js (已通过 _shared/js/ 加载)
 *
 * 图表清单:
 *   1. chart-size-breakdown      — 项目体积构成分析 (3.7 GB)
 *   2. chart-solution-comparison — 四种桌面封装方案对比
 *   3. chart-package-size        — 安装包体积构成预估 (271 MB)
 *   4. chart-timeline            — 实施路线图时间线
 */

(function () {
  'use strict';

  // ──────────────────────────────────────────────
  // 从 CSS 变量读取主题色
  // ──────────────────────────────────────────────
  var style = getComputedStyle(document.documentElement);
  var accent = style.getPropertyValue('--accent').trim() || '#2563eb';
  var accent2 = style.getPropertyValue('--accent2').trim() || '#059669';
  var ink = style.getPropertyValue('--ink').trim() || '#1a1d27';
  var muted = style.getPropertyValue('--muted').trim() || '#6b7280';
  var rule = style.getPropertyValue('--rule').trim() || '#e5e7eb';
  var danger = style.getPropertyValue('--danger').trim() || '#dc2626';
  var warning = style.getPropertyValue('--warning').trim() || '#d97706';

  // 颜色调色板（用于多分类图表）
  var palette = [accent, accent2, warning, danger, '#7c3aed', '#0891b2'];

  // 通用 textStyle
  var baseTextStyle = {
    fontFamily: "'Noto Sans SC', 'Microsoft YaHei', 'PingFang SC', sans-serif",
    color: ink,
  };

  // ──────────────────────────────────────────────
  // 图表1: 项目体积构成分析（3.7 GB 总量）
  // ──────────────────────────────────────────────
  function initSizeBreakdown() {
    var el = document.getElementById('chart-size-breakdown');
    if (!el || typeof echarts === 'undefined') return;

    var chart = echarts.init(el);
    var data = [
      { value: 1740, name: '.hf_cache 模型缓存', itemStyle: { color: danger } },
      { value: 1320, name: '.venv Python 环境', itemStyle: { color: warning } },
      { value: 446, name: 'node_modules 依赖', itemStyle: { color: '#7c3aed' } },
      { value: 155, name: '其他（配置/文档/脚本）', itemStyle: { color: muted } },
      { value: 11.5, name: '源代码', itemStyle: { color: accent2 } },
      { value: 5.7, name: '部署产物 dist/', itemStyle: { color: accent } },
    ];

    chart.setOption({
      title: {
        text: '3,778 MB',
        subtext: '项目总体积',
        left: 'center',
        top: '38%',
        textStyle: { fontSize: 28, fontWeight: 700, color: ink, fontFamily: baseTextStyle.fontFamily },
        subtextStyle: { fontSize: 13, color: muted, fontFamily: baseTextStyle.fontFamily },
      },
      tooltip: {
        trigger: 'item',
        formatter: function (p) {
          var pct = ((p.value / 3778.2) * 100).toFixed(2);
          return p.name + '<br/>' + p.value + ' MB (' + pct + '%)';
        },
      },
      legend: {
        orient: 'vertical',
        right: '5%',
        top: 'middle',
        textStyle: { fontSize: 13, color: ink, fontFamily: baseTextStyle.fontFamily },
        itemGap: 12,
      },
      series: [
        {
          type: 'pie',
          radius: ['42%', '68%'],
          center: ['42%', '50%'],
          avoidLabelOverlap: true,
          itemStyle: { borderColor: '#fff', borderWidth: 2 },
          label: {
            show: true,
            formatter: '{b}\n{d}%',
            fontSize: 11,
            color: ink,
            fontFamily: baseTextStyle.fontFamily,
          },
          labelLine: { length: 12, length2: 10 },
          data: data,
        },
      ],
    });

    window.addEventListener('resize', function () { chart.resize(); });
  }

  // ──────────────────────────────────────────────
  // 图表2: 四种桌面封装方案对比
  // ──────────────────────────────────────────────
  function initSolutionComparison() {
    var el = document.getElementById('chart-solution-comparison');
    if (!el || typeof echarts === 'undefined') return;

    var chart = echarts.init(el);

    chart.setOption({
      tooltip: {
        trigger: 'axis',
        axisPointer: { type: 'shadow' },
      },
      legend: {
        data: ['安装包大小 (MB)', '功能保留率 (%)'],
        top: 5,
        textStyle: { fontSize: 13, color: ink, fontFamily: baseTextStyle.fontFamily },
      },
      grid: { left: '8%', right: '8%', bottom: '12%', top: '20%' },
      xAxis: {
        type: 'category',
        data: ['A: Tauri\n+ 云端API', 'B: Electron\n+ Python', 'C: PyQt\n+ Flask', 'D: Tauri\n+ PyInstaller'],
        axisLabel: {
          fontSize: 12,
          color: ink,
          fontFamily: baseTextStyle.fontFamily,
          interval: 0,
          lineHeight: 16,
        },
        axisLine: { lineStyle: { color: rule } },
        axisTick: { show: false },
      },
      yAxis: [
        {
          type: 'value',
          name: '安装包 (MB)',
          nameTextStyle: { color: muted, fontSize: 12, fontFamily: baseTextStyle.fontFamily },
          axisLabel: { color: muted, fontSize: 11, fontFamily: baseTextStyle.fontFamily },
          splitLine: { lineStyle: { color: rule, type: 'dashed' } },
        },
        {
          type: 'value',
          name: '功能保留 (%)',
          max: 120,
          nameTextStyle: { color: muted, fontSize: 12, fontFamily: baseTextStyle.fontFamily },
          axisLabel: { color: muted, fontSize: 11, formatter: '{value}%', fontFamily: baseTextStyle.fontFamily },
          splitLine: { show: false },
        },
      ],
      series: [
        {
          name: '安装包大小 (MB)',
          type: 'bar',
          barWidth: '28%',
          data: [
            { value: 19, itemStyle: { color: danger } },
            { value: 271, itemStyle: { color: accent2 } },
            { value: 180, itemStyle: { color: warning } },
            { value: 271, itemStyle: { color: '#7c3aed' } },
          ],
          label: {
            show: true,
            position: 'top',
            formatter: '{c} MB',
            fontSize: 12,
            color: ink,
            fontFamily: baseTextStyle.fontFamily,
          },
        },
        {
          name: '功能保留率 (%)',
          type: 'line',
          yAxisIndex: 1,
          symbol: 'circle',
          symbolSize: 10,
          lineStyle: { width: 3, color: accent },
          itemStyle: { color: accent },
          data: [
            { value: 45 },
            { value: 100 },
            { value: 100 },
            { value: 100 },
          ],
          label: {
            show: true,
            position: 'top',
            formatter: '{c}%',
            fontSize: 12,
            color: accent,
            fontWeight: 600,
            fontFamily: baseTextStyle.fontFamily,
          },
        },
      ],
    });

    window.addEventListener('resize', function () { chart.resize(); });
  }

  // ──────────────────────────────────────────────
  // 图表3: 安装包体积构成预估（271 MB 总量）
  // ──────────────────────────────────────────────
  function initPackageSize() {
    var el = document.getElementById('chart-package-size');
    if (!el || typeof echarts === 'undefined') return;

    var chart = echarts.init(el);
    var data = [
      { value: 90, name: 'Python 运行时 + 依赖库', itemStyle: { color: accent } },
      { value: 90, name: 'MiniLM 预装模型', itemStyle: { color: accent2 } },
      { value: 85, name: 'Electron 框架 (Chromium)', itemStyle: { color: warning } },
      { value: 5, name: '前端构建产物 dist/', itemStyle: { color: '#7c3aed' } },
      { value: 1, name: '其他资源', itemStyle: { color: muted } },
    ];

    chart.setOption({
      title: {
        text: '271 MB',
        subtext: '安装包总体积',
        left: 'center',
        top: '38%',
        textStyle: { fontSize: 28, fontWeight: 700, color: ink, fontFamily: baseTextStyle.fontFamily },
        subtextStyle: { fontSize: 13, color: muted, fontFamily: baseTextStyle.fontFamily },
      },
      tooltip: {
        trigger: 'item',
        formatter: function (p) {
          var pct = ((p.value / 271) * 100).toFixed(1);
          return p.name + '<br/>' + p.value + ' MB (' + pct + '%)';
        },
      },
      legend: {
        orient: 'vertical',
        right: '5%',
        top: 'middle',
        textStyle: { fontSize: 13, color: ink, fontFamily: baseTextStyle.fontFamily },
        itemGap: 12,
      },
      series: [
        {
          type: 'pie',
          radius: ['42%', '68%'],
          center: ['42%', '50%'],
          avoidLabelOverlap: true,
          itemStyle: { borderColor: '#fff', borderWidth: 2 },
          label: {
            show: true,
            formatter: '{b}\n{d}%',
            fontSize: 11,
            color: ink,
            fontFamily: baseTextStyle.fontFamily,
          },
          labelLine: { length: 12, length2: 10 },
          data: data,
        },
      ],
      graphic: [
        {
          type: 'text',
          left: 'center',
          bottom: 10,
          style: {
            text: '对比 3.7 GB 原始体积，压缩率 92.7%',
            fontSize: 12,
            fill: accent2,
            fontFamily: baseTextStyle.fontFamily,
          },
        },
      ],
    });

    window.addEventListener('resize', function () { chart.resize(); });
  }

  // ──────────────────────────────────────────────
  // 图表4: 实施路线图时间线
  // ──────────────────────────────────────────────
  function initTimeline() {
    var el = document.getElementById('chart-timeline');
    if (!el || typeof echarts === 'undefined') return;

    var chart = echarts.init(el);

    // 使用横向条形图模拟甘特图
    var phases = [
      {
        name: 'Phase 3: 测试与发布',
        start: 6,
        duration: 3,
        color: accent2,
        tasks: ['端到端功能测试', 'Sidecar 崩溃恢复', '端口冲突测试', '冷启动性能测试', '模型按需下载验证'],
      },
      {
        name: 'Phase 2: 打包与构建',
        start: 4,
        duration: 2,
        color: warning,
        tasks: ['PyInstaller 配置', 'electron-builder 打包', 'NSIS 安装包生成', 'UPX 体积优化'],
      },
      {
        name: 'Phase 1: 基础框架搭建',
        start: 0,
        duration: 4,
        color: accent,
        tasks: ['Electron 项目结构', 'main/preload/proxy/sidecar', 'sidecar_entry.py', '开发环境联调'],
      },
    ];

    chart.setOption({
      tooltip: {
        trigger: 'item',
        formatter: function (p) {
          var d = phases[p.dataIndex];
          var taskList = d.tasks.map(function (t) { return '  • ' + t; }).join('\n');
          return '<strong>' + d.name + '</strong>\n'
            + '周期: 第' + (d.start + 1) + '-' + (d.start + d.duration) + '天 (' + d.duration + '天)\n\n'
            + taskList;
        },
      },
      grid: { left: '18%', right: '10%', bottom: '10%', top: '8%' },
      xAxis: {
        type: 'value',
        name: '天数',
        nameLocation: 'middle',
        nameGap: 28,
        nameTextStyle: { color: muted, fontSize: 12, fontFamily: baseTextStyle.fontFamily },
        axisLabel: {
          color: muted,
          fontSize: 11,
          fontFamily: baseTextStyle.fontFamily,
          formatter: function (v) { return '第' + (v + 1) + '天'; },
        },
        splitLine: { lineStyle: { color: rule, type: 'dashed' } },
        max: 10,
      },
      yAxis: {
        type: 'category',
        data: phases.map(function (p) { return p.name; }),
        axisLabel: {
          color: ink,
          fontSize: 13,
          fontWeight: 600,
          fontFamily: baseTextStyle.fontFamily,
        },
        axisLine: { lineStyle: { color: rule } },
        axisTick: { show: false },
      },
      series: [
        // 透明条用于创建偏移效果（模拟甘特图起始位置）
        {
          type: 'bar',
          barWidth: '45%',
          stack: 'gantt',
          silent: true,
          itemStyle: { color: 'transparent' },
          data: phases.map(function (p) { return p.start; }),
        },
        // 实际阶段条（显示持续天数）
        {
          type: 'bar',
          barWidth: '45%',
          stack: 'gantt',
          data: phases.map(function (p) {
            return {
              value: p.duration,
              itemStyle: {
                color: p.color,
                borderRadius: [0, 4, 4, 0],
                opacity: 0.85,
              },
            };
          }),
          label: {
            show: true,
            position: 'right',
            formatter: function (p) {
              var d = phases[p.dataIndex];
              return d.duration + ' 天 (第' + (d.start + 1) + '-' + (d.start + d.duration) + '天)';
            },
            fontSize: 11,
            color: ink,
            fontFamily: baseTextStyle.fontFamily,
          },
        },
      ],
    });

    window.addEventListener('resize', function () { chart.resize(); });
  }

  // ──────────────────────────────────────────────
  // 初始化所有图表
  // ──────────────────────────────────────────────
  function initAll() {
    initSizeBreakdown();
    initSolutionComparison();
    initPackageSize();
    initTimeline();
  }

  // DOM 就绪后初始化
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initAll);
  } else {
    initAll();
  }
})();
