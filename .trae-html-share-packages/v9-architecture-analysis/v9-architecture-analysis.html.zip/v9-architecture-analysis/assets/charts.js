(function() {
  var style = getComputedStyle(document.documentElement);
  var accent = style.getPropertyValue('--accent').trim();
  var accent2 = style.getPropertyValue('--accent2').trim();
  var ink = style.getPropertyValue('--ink').trim();
  var muted = style.getPropertyValue('--muted').trim();
  var rule = style.getPropertyValue('--rule').trim();
  var bg2 = style.getPropertyValue('--bg2').trim();
  var danger = style.getPropertyValue('--danger').trim();
  var success = style.getPropertyValue('--success').trim();
  var warning = style.getPropertyValue('--warning').trim();

  // --- Chart 1: 3.7G Size Breakdown (Pie) ---
  var chart1 = echarts.init(document.getElementById('chart-size-breakdown'), null, { renderer: 'svg' });
  chart1.setOption({
    title: {
      text: '3.7G 工作目录构成',
      left: 'center',
      top: 10,
      textStyle: { color: ink, fontSize: 14, fontWeight: 600 }
    },
    tooltip: {
      trigger: 'item',
      appendToBody: true,
      formatter: '{b}: {c} MB ({d}%)'
    },
    legend: {
      orient: 'vertical',
      right: 10,
      top: 'center',
      textStyle: { color: muted, fontSize: 11 },
      itemWidth: 12,
      itemHeight: 12
    },
    series: [{
      type: 'pie',
      radius: ['35%', '65%'],
      center: ['38%', '55%'],
      avoidLabelOverlap: true,
      itemStyle: { borderColor: bg2, borderWidth: 2 },
      label: {
        show: true,
        formatter: '{d}%',
        color: ink,
        fontSize: 11,
        fontWeight: 600
      },
      emphasis: {
        label: { show: true, fontSize: 13, fontWeight: 'bold' }
      },
      data: [
        { value: 1742, name: '.hf_cache (AI模型缓存)', itemStyle: { color: danger } },
        { value: 1315, name: '.venv (Python虚拟环境)', itemStyle: { color: '#dc2626' } },
        { value: 446, name: 'node_modules (Node依赖)', itemStyle: { color: accent2 } },
        { value: 57, name: '.git (版本控制)', itemStyle: { color: muted } },
        { value: 47, name: 'outputs (开发产物)', itemStyle: { color: '#6b7280' } },
        { value: 45, name: 'scripts (工具脚本)', itemStyle: { color: '#6b7280' } },
        { value: 34, name: 'docs (文档)', itemStyle: { color: '#6b7280' } },
        { value: 25, name: 'e2e (E2E测试)', itemStyle: { color: '#6b7280' } },
        { value: 11.5, name: 'src (源代码)', itemStyle: { color: success } },
        { value: 10.3, name: 'archive (归档)', itemStyle: { color: '#4b5563' } },
        { value: 5.7, name: 'dist (部署产物)', itemStyle: { color: accent } },
        { value: 7, name: '其他', itemStyle: { color: '#374151' } }
      ]
    }],
    animation: false
  });
  window.addEventListener('resize', function() { chart1.resize(); });

  // --- Chart 2: .venv Top Packages (Bar) ---
  var chart2 = echarts.init(document.getElementById('chart-venv-packages'), null, { renderer: 'svg' });
  chart2.setOption({
    title: {
      text: '.venv/site-packages 前 10 大包',
      left: 'center',
      top: 10,
      textStyle: { color: ink, fontSize: 14, fontWeight: 600 }
    },
    tooltip: {
      trigger: 'axis',
      appendToBody: true,
      axisPointer: { type: 'shadow' },
      formatter: '{b}: {c} MB'
    },
    grid: { left: 100, right: 30, top: 50, bottom: 20 },
    xAxis: {
      type: 'value',
      axisLabel: { color: muted, fontSize: 11, formatter: '{value} MB' },
      splitLine: { lineStyle: { color: rule } },
      axisLine: { lineStyle: { color: rule } }
    },
    yAxis: {
      type: 'category',
      data: ['torch', 'scipy', 'playwright', 'transformers', 'sympy', 'pandas', 'sklearn', 'py_mini_racer', 'numpy', 'matplotlib'],
      axisLabel: { color: ink, fontSize: 11 },
      axisLine: { lineStyle: { color: rule } }
    },
    series: [{
      type: 'bar',
      data: [497, 109, 106, 99, 69, 62, 41, 38, 31, 31],
      itemStyle: {
        color: function(params) {
          var colors = [danger, accent2, accent2, accent2, accent2, accent2, accent2, muted, muted, muted];
          return colors[params.dataIndex];
        },
        borderRadius: [0, 3, 3, 0]
      },
      barWidth: '60%',
      label: {
        show: true,
        position: 'right',
        color: ink,
        fontSize: 11,
        formatter: '{c} MB'
      }
    }],
    animation: false
  });
  window.addEventListener('resize', function() { chart2.resize(); });

  // --- Chart 3: src/ Subdirectory Breakdown (Bar) ---
  var chart3 = echarts.init(document.getElementById('chart-src-breakdown'), null, { renderer: 'svg' });
  chart3.setOption({
    title: {
      text: 'src/ 各子目录大小 (KB)',
      left: 'center',
      top: 10,
      textStyle: { color: ink, fontSize: 14, fontWeight: 600 }
    },
    tooltip: {
      trigger: 'axis',
      appendToBody: true,
      axisPointer: { type: 'shadow' },
      formatter: function(params) {
        var p = params[0];
        return p.name + ': ' + p.value + ' KB (' + (p.value / 11500 * 100).toFixed(1) + '%)';
      }
    },
    grid: { left: 100, right: 50, top: 50, bottom: 20 },
    xAxis: {
      type: 'value',
      axisLabel: { color: muted, fontSize: 11, formatter: '{value} KB' },
      splitLine: { lineStyle: { color: rule } },
      axisLine: { lineStyle: { color: rule } }
    },
    yAxis: {
      type: 'category',
      data: ['其他', 'types', 'config', 'mcp', 'lib', 'cockpit', 'data', 'core', 'pages', 'components', 'store', 'services'],
      axisLabel: { color: ink, fontSize: 11 },
      axisLine: { lineStyle: { color: rule } }
    },
    series: [{
      type: 'bar',
      data: [
        { value: 590, itemStyle: { color: muted } },
        { value: 170, itemStyle: { color: muted } },
        { value: 240, itemStyle: { color: muted } },
        { value: 320, itemStyle: { color: warning } },
        { value: 420, itemStyle: { color: accent } },
        { value: 440, itemStyle: { color: accent } },
        { value: 540, itemStyle: { color: accent } },
        { value: 640, itemStyle: { color: accent } },
        { value: 920, itemStyle: { color: accent } },
        { value: 1210, itemStyle: { color: accent } },
        { value: 1850, itemStyle: { color: accent } },
        { value: 4160, itemStyle: { color: success } }
      ],
      itemStyle: { borderRadius: [0, 3, 3, 0] },
      barWidth: '60%',
      label: {
        show: true,
        position: 'right',
        color: ink,
        fontSize: 10,
        formatter: '{c} KB'
      }
    }],
    animation: false
  });
  window.addEventListener('resize', function() { chart3.resize(); });

  // --- Mermaid Init ---
  if (typeof mermaid !== 'undefined') {
    mermaid.initialize({
      startOnLoad: true,
      theme: 'dark',
      themeVariables: {
        primaryColor: '#1a3a5c',
        primaryTextColor: '#e8e9ed',
        primaryBorderColor: '#3b82f6',
        lineColor: '#8b8fa3',
        secondaryColor: '#1a1d27',
        tertiaryColor: '#232838',
        fontFamily: '-apple-system, "Segoe UI", "Noto Sans CJK SC", "Microsoft YaHei", sans-serif'
      },
      securityLevel: 'loose',
      flowchart: { curve: 'basis', htmlLabels: true }
    });
  }
})();
