(function() {
  'use strict';

  var style = getComputedStyle(document.documentElement);
  var accent = style.getPropertyValue('--accent').trim();
  var accent2 = style.getPropertyValue('--accent2').trim();
  var ink = style.getPropertyValue('--ink').trim();
  var muted = style.getPropertyValue('--muted').trim();
  var rule = style.getPropertyValue('--rule').trim();
  var bg2 = style.getPropertyValue('--bg2').trim();
  var danger = style.getPropertyValue('--danger').trim();
  var success = style.getPropertyValue('--success').trim();
  var warning = style.getPropertyValue('--warning').trim();

  // --- Chart 1: Packaging Options Comparison (Bar + Line combo) ---
  var chart1 = echarts.init(document.getElementById('chart-comparison'), null, { renderer: 'svg' });
  chart1.setOption({
    title: {
      text: '安装包大小 vs 功能覆盖率',
      left: 'center',
      top: 10,
      textStyle: { color: ink, fontSize: 14, fontWeight: 600 }
    },
    tooltip: {
      trigger: 'axis',
      appendToBody: true,
      axisPointer: { type: 'shadow' }
    },
    legend: {
      bottom: 5,
      textStyle: { color: muted, fontSize: 11 },
      itemWidth: 12,
      itemHeight: 12
    },
    grid: {
      left: '8%',
      right: '8%',
      top: '18%',
      bottom: '15%'
    },
    xAxis: {
      type: 'category',
      data: ['方案A\n去Python\n(已否决)', '方案D\n保留Python\n(推荐)', '方案B\nElectron\n+Python'],
      axisLabel: { color: ink, fontSize: 11, lineHeight: 14 },
      axisLine: { lineStyle: { color: rule } }
    },
    yAxis: [
      {
        type: 'value',
        name: '安装包 (MB)',
        position: 'left',
        nameTextStyle: { color: muted, fontSize: 10 },
        axisLabel: { color: muted, fontSize: 10 },
        splitLine: { lineStyle: { color: rule, opacity: 0.3 } },
        max: 1600
      },
      {
        type: 'value',
        name: '功能覆盖 (%)',
        position: 'right',
        min: 0,
        max: 100,
        nameTextStyle: { color: muted, fontSize: 10 },
        axisLabel: { color: muted, fontSize: 10, formatter: '{value}%' },
        splitLine: { show: false }
      }
    ],
    series: [
      {
        name: '安装包大小 (MB)',
        type: 'bar',
        barWidth: '30%',
        data: [
          { value: 19, itemStyle: { color: danger, opacity: 0.7 } },
          { value: 271, itemStyle: { color: success } },
          { value: 1500, itemStyle: { color: warning, opacity: 0.7 } }
        ],
        label: {
          show: true,
          position: 'top',
          color: ink,
          fontSize: 12,
          fontWeight: 600,
          formatter: '{c} MB'
        }
      },
      {
        name: '功能覆盖率',
        type: 'line',
        yAxisIndex: 1,
        data: [
          { value: 45, itemStyle: { color: danger } },
          { value: 100, itemStyle: { color: success } },
          { value: 100, itemStyle: { color: warning } }
        ],
        symbol: 'circle',
        symbolSize: 10,
        lineStyle: { color: accent, width: 2 },
        itemStyle: { color: accent },
        label: {
          show: true,
          position: 'top',
          color: accent,
          fontSize: 11,
          fontWeight: 600,
          formatter: '{c}%'
        }
      }
    ],
    animation: false
  });

  // Responsive
  window.addEventListener('resize', function() {
    chart1.resize();
  });
})();
