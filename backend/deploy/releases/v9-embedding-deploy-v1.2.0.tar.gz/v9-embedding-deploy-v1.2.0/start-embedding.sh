#!/usr/bin/env bash
# ============================================================================
# V9 Embedding Service — 多 Worker 启动脚本
# ============================================================================
#
# 基于 ADR-014 性能基准结论：
#   - CPU 密集推理场景推荐 --workers 1（实测 QPS 比 4 worker 高 84.9%）
#   - GPU 场景可启用 2-4 worker（需重新基准测试）
#   - 高并发场景建议横向扩展（多实例 + Nginx），而非单实例多 worker
#
# 用法:
#   ./start-embedding.sh              # 默认启动（1 worker, CPU 推理）
#   ./start-embedding.sh --workers 4  # GPU 场景 4 worker
#   ./start-embedding.sh --model bge  # 切换到 bge-large-zh-v1.5
#   ./start-embedding.sh --debug      # DEBUG 日志模式（排查延迟问题）
#   ./start-embedding.sh --gpu        # GPU 模式（自动检测 CUDA）
#
# 环境变量（可覆盖默认值）:
#   EMBEDDING_MODEL            模型 ID (默认: all-MiniLM-L6-v2)
#   UVICORN_WORKERS           Worker 数 (默认: 1)
#   EMBEDDING_LOG_LEVEL       日志级别 (默认: INFO)
#   EMBEDDING_WARMUP          启动预热 (默认: true)
#   EMBEDDING_MAX_BATCH       批量上限 (默认: 64)
#   EMBEDDING_SLOW_THRESHOLD  慢请求阈值 ms (默认: 500)
#   UVICORN_HOST              监听地址 (默认: 0.0.0.0)
#   UVICORN_PORT              监听端口 (默认: 8001)
#   HF_HOME                   HuggingFace 缓存路径
# ============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# ---------------------------------------------------------------------------
# 默认配置（CPU 推理场景最优，基于实测数据）
# ---------------------------------------------------------------------------
WORKERS="${UVICORN_WORKERS:-1}"
MODEL="${EMBEDDING_MODEL:-all-MiniLM-L6-v2}"
LOG_LEVEL="${EMBEDDING_LOG_LEVEL:-INFO}"
WARMUP="${EMBEDDING_WARMUP:-true}"
MAX_BATCH="${EMBEDDING_MAX_BATCH:-64}"
SLOW_THRESHOLD="${EMBEDDING_SLOW_THRESHOLD:-500}"
HOST="${UVICORN_HOST:-0.0.0.0}"
PORT="${UVICORN_PORT:-8001}"
GPU_MODE="${GPU_MODE:-false}"

# ---------------------------------------------------------------------------
# 参数解析
# ---------------------------------------------------------------------------
while [[ $# -gt 0 ]]; do
    case "$1" in
        --workers)
            WORKERS="$2"; shift 2 ;;
        --model)
            MODEL="$2"; shift 2 ;;
        --debug)
            LOG_LEVEL="DEBUG"; shift ;;
        --gpu)
            GPU_MODE="true"; WORKERS="${UVICORN_WORKERS:-2}"; shift ;;
        --port)
            PORT="$2"; shift 2 ;;
        --host)
            HOST="$2"; shift 2 ;;
        --no-warmup)
            WARMUP="false"; shift ;;
        *)
            echo "未知参数: $1" >&2; exit 1 ;;
    esac
done

# ---------------------------------------------------------------------------
# GPU 自动检测
# ---------------------------------------------------------------------------
if [[ "$GPU_MODE" == "true" ]]; then
    if python -c "import torch; assert torch.cuda.is_available()" 2>/dev/null; then
        GPU_COUNT=$(python -c "import torch; print(torch.cuda.device_count())")
        GPU_NAME=$(python -c "import torch; print(torch.cuda.get_device_name(0))")
        GPU_MEM=$(python -c "import torch; print(f'{torch.cuda.get_device_properties(0).total_memory / 1024**3:.1f}GB')")
        echo "[GPU] 检测到 ${GPU_COUNT} × ${GPU_NAME} (显存 ${GPU_MEM})"

        if [[ "$WORKERS" -gt "$((GPU_COUNT * 2))" ]]; then
            echo "[GPU] 警告: Worker 数 ($WORKERS) 超过推荐上限 ($((GPU_COUNT * 2)))，可能导致 GPU 显存不足"
        fi
    else
        echo "[GPU] 未检测到 CUDA 设备，回退到 CPU 模式 (--workers 1)"
        GPU_MODE="false"
        WORKERS=1
    fi
fi

# ---------------------------------------------------------------------------
# CPU 模式强制单 Worker（基于 ADR-014 实测结论）
# ---------------------------------------------------------------------------
if [[ "$GPU_MODE" != "true" && "$WORKERS" -ne 1 ]]; then
    echo "[WARN] CPU 密集推理场景下，--workers $WORKERS 性能将低于 --workers 1"
    echo "       实测数据: 1 worker QPS=90.67, $WORKERS worker QPS=$(python -c \"print(round(90.67 * {1: 1, 2: 0.865, 4: 0.541}.get($WORKERS, 0.5), 2))\" 2>/dev/null || echo 'N/A')"
    echo "       建议: 使用 --workers 1 或启用 --gpu 模式"
    read -rp "       继续使用 $WORKERS worker? [y/N] " confirm
    if [[ "$confirm" != "y" ]]; then
        WORKERS=1
        echo "[INFO] 已自动切换为 --workers 1"
    fi
fi

# ---------------------------------------------------------------------------
# 事件循环与 HTTP 解析器检测
# ---------------------------------------------------------------------------
LOOP="auto"
HTTP="auto"
if python -c "import uvloop" 2>/dev/null; then
    LOOP="uvloop"
    echo "[PERF] 检测到 uvloop，启用高性能事件循环"
fi
if python -c "import httptools" 2>/dev/null; then
    HTTP="httptools"
    echo "[PERF] 检测到 httptools，启用高性能 HTTP 解析器"
fi

# ---------------------------------------------------------------------------
# 启动前检查
# ---------------------------------------------------------------------------
echo "=============================================="
echo " V9 Embedding Service 启动配置"
echo "=============================================="
echo " 模型:       $MODEL"
echo " Worker:     $WORKERS"
echo " 日志级别:   $LOG_LEVEL"
echo " 预热:       $WARMUP"
echo " 批量上限:   $MAX_BATCH"
echo " 慢请求阈值: ${SLOW_THRESHOLD}ms"
echo " 监听:       ${HOST}:${PORT}"
echo " Loop:       $LOOP"
echo " HTTP:       $HTTP"
echo " GPU 模式:   $GPU_MODE"
echo "=============================================="

# 检查端口占用
if ! python -c "
import socket, sys
s = socket.socket()
try:
    s.bind(('0.0.0.0', $PORT))
    s.close()
    sys.exit(0)
except OSError:
    sys.exit(1)
" 2>/dev/null; then
    echo "[ERROR] 端口 $PORT 已被占用，请先释放或指定其他端口: --port <new_port>"
    exit 1
fi

# 检查 Python 依赖
python -c "import fastapi, uvicorn, sentence_transformers" 2>/dev/null || {
    echo "[ERROR] 缺少 Python 依赖，请先安装:"
    echo "        pip install -r requirements.txt"
    exit 1
}

# ---------------------------------------------------------------------------
# 构建并执行启动命令
# ---------------------------------------------------------------------------
CMD=(
    uvicorn embedding_service:app
    --host "$HOST"
    --port "$PORT"
    --workers "$WORKERS"
    --loop "$LOOP"
    --http "$HTTP"
    --log-level "$(echo "$LOG_LEVEL" | tr '[:upper:]' '[:lower:]')"
    --access-log
    --no-date-headers
)

# GPU 模式下设置 CUDA 相关环境变量
if [[ "$GPU_MODE" == "true" ]]; then
    export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}"
    export OMP_NUM_THREADS="${OMP_NUM_THREADS:-4}"
    echo "[GPU] CUDA_VISIBLE_DEVICES=$CUDA_VISIBLE_DEVICES"
    echo "[GPU] OMP_NUM_THREADS=$OMP_NUM_THREADS"
fi

# 设置核心环境变量
export EMBEDDING_MODEL="$MODEL"
export EMBEDDING_LOG_LEVEL="$LOG_LEVEL"
export EMBEDDING_WARMUP="$WARMUP"
export EMBEDDING_MAX_BATCH="$MAX_BATCH"
export EMBEDDING_SLOW_THRESHOLD_MS="$SLOW_THRESHOLD"
export HF_HOME="${HF_HOME:-/app/hf_cache}"
export PYTHONUNBUFFERED=1

echo ""
echo "[START] 启动 Embedding Service..."
echo "[CMD] ${CMD[*]}"
echo ""

exec "${CMD[@]}"
