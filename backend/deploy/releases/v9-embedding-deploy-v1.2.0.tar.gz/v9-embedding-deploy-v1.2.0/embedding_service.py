"""
V9 Embedding Service — 云端 Embedding API（v2.0.0 Week 2 升级）

基于 sentence-transformers 提供文本嵌入服务，
替代前端 @xenova/transformers 本地推理（108 MB → 0 MB bundle）。

支持通过环境变量 EMBEDDING_MODEL 动态切换模型：
  - all-MiniLM-L6-v2 (384维, 默认, 英文优化)
  - bge-large-zh-v1.5 (1024维, 中文优化)

启动：
  # 默认模型 (all-MiniLM-L6-v2)
  uvicorn embedding_service:app --host 0.0.0.0 --port 8001

  # 切换到 bge-large-zh-v1.5
  EMBEDDING_MODEL=bge-large-zh-v1.5 uvicorn embedding_service:app --host 0.0.0.0 --port 8002

  # 多 worker 模式（生产环境推荐）
  uvicorn embedding_service:app --host 0.0.0.0 --port 8001 --workers 4

  # 启用 uvloop + httptools（v2.0.0 性能优化，Linux/macOS）
  uvicorn embedding_service:app --host 0.0.0.0 --port 8001 --workers 4 \
    --loop uvloop --http httptools

接口契约（与前端 cloudEmbeddingService.ts 保持兼容）：
  POST /api/embed         — 批量文本嵌入（同步路由，线程池执行）
  GET  /api/embed/health  — 健康检查 + 模型状态
  GET  /api/embed/config  — 模型配置信息（v2.0.0 新增）
  GET  /api/embed/metrics — 运行时性能指标（v2.0.0 新增）
"""

import os
import time
import uuid
import logging
import threading
from typing import Optional

# HuggingFace 国内镜像（避免 huggingface.co 被墙导致模型下载失败）
os.environ.setdefault("HF_ENDPOINT", "https://hf-mirror.com")

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

# ---------------------------------------------------------------------------
# 日志配置
# ---------------------------------------------------------------------------

# 日志级别可通过环境变量控制（默认 INFO，排查延迟问题时可设为 DEBUG）
# DEBUG 级别会输出请求进入、编码前后、缓存命中等详细诊断日志
LOG_LEVEL = os.environ.get("EMBEDDING_LOG_LEVEL", "INFO").upper()

logging.basicConfig(
    level=logging.INFO,  # root logger 保持 INFO，避免 httpx 等第三方库 DEBUG 刷屏
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("embedding_service")
logger.setLevel(LOG_LEVEL)  # embedding_service logger 单独控制级别

app = FastAPI(title="V9 Embedding Service", version="2.0.0")

# ---------------------------------------------------------------------------
# CORS — 允许前端开发服务器访问
# ---------------------------------------------------------------------------

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["*"],
)

# ---------------------------------------------------------------------------
# 模型注册表 — 支持多模型切换
# ---------------------------------------------------------------------------

MODEL_REGISTRY = {
    "all-MiniLM-L6-v2": {
        "hf_repo": "sentence-transformers/all-MiniLM-L6-v2",
        "dimension": 384,
        "max_tokens": 256,
        "size_mb": 23,
        "language": "多语言（英文优先）",
        "description": "轻量级多语言模型，推理速度快",
    },
    "bge-large-zh-v1.5": {
        "hf_repo": "BAAI/bge-large-zh-v1.5",
        "dimension": 1024,
        "max_tokens": 512,
        "size_mb": 1300,
        "language": "中文专用",
        "description": "C-MTEB Top 5 中文嵌入模型，中文检索精度高",
        # bge 模型查询时建议添加 instruction（提升检索效果）
        "query_instruction": "为这个句子生成表示以用于检索相关文章：",
    },
}

# ---------------------------------------------------------------------------
# 环境变量配置（命名规范：EMBEDDING_ 前缀）
# ---------------------------------------------------------------------------

# 模型 ID（默认 bge-large-zh-v1.5，中文财经文本检索精度高）
# 如需切回轻量模型：EMBEDDING_MODEL=all-MiniLM-L6-v2
EMBEDDING_MODEL = os.environ.get("EMBEDDING_MODEL", "bge-large-zh-v1.5")

# 批量推理上限（避免单次请求过大导致 OOM）
MAX_BATCH_SIZE = int(os.environ.get("EMBEDDING_MAX_BATCH", "64"))

# 是否启用预热（启动时立即加载模型，避免首次请求慢）
WARMUP_ON_START = os.environ.get("EMBEDDING_WARMUP", "false").lower() == "true"

# 慢请求阈值（毫秒）：超过此值会打印 WARN 日志，便于排查延迟问题
SLOW_REQUEST_THRESHOLD_MS = float(os.environ.get("EMBEDDING_SLOW_THRESHOLD_MS", "500"))

# 验证模型 ID 有效性
if EMBEDDING_MODEL not in MODEL_REGISTRY:
    logger.error(
        "未知的 EMBEDDING_MODEL=%s，可选值: %s",
        EMBEDDING_MODEL,
        list(MODEL_REGISTRY.keys()),
    )
    raise SystemExit(f"Invalid EMBEDDING_MODEL: {EMBEDDING_MODEL}")

# 从注册表获取模型配置
_MODEL_CONFIG = MODEL_REGISTRY[EMBEDDING_MODEL]
EMBEDDING_MODEL_ID = EMBEDDING_MODEL
EMBEDDING_DIMENSION = _MODEL_CONFIG["dimension"]
_HF_REPO = _MODEL_CONFIG["hf_repo"]
_QUERY_INSTRUCTION = _MODEL_CONFIG.get("query_instruction")

# ---------------------------------------------------------------------------
# 运行时性能指标收集（v2.0.0 新增）
# ---------------------------------------------------------------------------

class _Metrics:
    """线程安全的运行时指标收集器"""

    def __init__(self):
        self._lock = threading.Lock()
        self._start_time = time.time()
        self._total_requests = 0
        self._total_texts = 0
        self._total_inference_ms = 0.0
        self._latencies_ms: list[float] = []  # 仅保留最近 100 个用于 P50/P95/P99

    def record(self, inference_ms: float, num_texts: int) -> None:
        with self._lock:
            self._total_requests += 1
            self._total_texts += num_texts
            self._total_inference_ms += inference_ms
            self._latencies_ms.append(inference_ms)
            # 仅保留最近 100 个样本，避免内存增长
            if len(self._latencies_ms) > 100:
                self._latencies_ms = self._latencies_ms[-100:]

    def snapshot(self) -> dict:
        with self._lock:
            n = len(self._latencies_ms)
            if n == 0:
                p50 = p95 = p99 = 0.0
            else:
                sorted_l = sorted(self._latencies_ms)
                p50 = sorted_l[n // 2]
                p95 = sorted_l[int(n * 0.95)]
                p99 = sorted_l[int(n * 0.99)] if n > 1 else sorted_l[0]
            uptime_s = time.time() - self._start_time
            return {
                "uptime_seconds": round(uptime_s, 1),
                "total_requests": self._total_requests,
                "total_texts_embedded": self._total_texts,
                "avg_inference_ms": round(self._total_inference_ms / self._total_requests, 2)
                if self._total_requests > 0
                else 0.0,
                "recent_p50_ms": round(p50, 2),
                "recent_p95_ms": round(p95, 2),
                "recent_p99_ms": round(p99, 2),
                "recent_samples": n,
                "throughput_req_per_s": round(self._total_requests / uptime_s, 3)
                if uptime_s > 0
                else 0.0,
                "throughput_texts_per_s": round(self._total_texts / uptime_s, 3)
                if uptime_s > 0
                else 0.0,
            }


_metrics = _Metrics()

logger.info(
    "Embedding Service 配置: model=%s, dim=%d, repo=%s, max_batch=%d, warmup=%s, slow_threshold=%dms",
    EMBEDDING_MODEL_ID,
    EMBEDDING_DIMENSION,
    _HF_REPO,
    MAX_BATCH_SIZE,
    WARMUP_ON_START,
    SLOW_REQUEST_THRESHOLD_MS,
)

# ---------------------------------------------------------------------------
# 模型懒加载（首次请求时加载，避免启动慢）
# ---------------------------------------------------------------------------

_model = None
_model_loading = False
_model_load_error: Optional[str] = None


def get_model():
    """获取 SentenceTransformer 模型实例（懒加载 + 单例）"""
    global _model, _model_loading, _model_load_error

    if _model is not None:
        # 缓存命中 — 模型已加载，直接返回（高频路径，仅 DEBUG 级别）
        logger.debug("模型缓存命中: %s", EMBEDDING_MODEL_ID)
        return _model

    if _model_loading:
        # 并发请求时，首个请求正在加载模型，后续请求需等待
        logger.warning("模型正在加载中，并发请求被拒绝（503）")
        raise HTTPException(status_code=503, detail="模型加载中，请稍后重试")

    if _model_load_error:
        logger.error("模型此前加载失败，拒绝请求: %s", _model_load_error)
        raise HTTPException(
            status_code=500,
            detail=f"模型加载失败（需重启服务重试）: {_model_load_error}",
        )

    _model_loading = True
    try:
        from sentence_transformers import SentenceTransformer

        logger.info("开始加载嵌入模型: %s (repo=%s, dim=%d)",
                    EMBEDDING_MODEL_ID, _HF_REPO, EMBEDDING_DIMENSION)
        start = time.time()
        _model = SentenceTransformer(_HF_REPO)
        elapsed = time.time() - start

        # 验证模型维度
        actual_dim = _model.get_sentence_embedding_dimension()
        if actual_dim != EMBEDDING_DIMENSION:
            logger.warning(
                "模型维度不匹配: 预期=%d, 实际=%d，以实际为准",
                EMBEDDING_DIMENSION, actual_dim,
            )

        logger.info(
            "模型加载完成: %s (%.1fs), 维度=%d, max_seq_length=%s",
            EMBEDDING_MODEL_ID, elapsed, actual_dim,
            getattr(_model, "max_seq_length", "unknown"),
        )
    except Exception as e:
        _model_load_error = str(e)
        logger.error("模型加载失败: %s — %s", EMBEDDING_MODEL_ID, e, exc_info=True)
        raise HTTPException(status_code=500, detail=f"模型加载失败: {e}")
    finally:
        _model_loading = False

    return _model


def _encode_with_instruction(texts: list[str], is_query: bool = False) -> list[list[float]]:
    """
    编码文本，自动处理 bge 模型的 query instruction。

    bge-large-zh-v1.5 建议查询时添加 instruction 以提升检索效果，
    文档编码时不添加。all-MiniLM-L6-v2 不需要 instruction。
    """
    model = get_model()

    # 记录编码前的文本统计（DEBUG 级别，用于排查延迟）
    total_chars = sum(len(t) for t in texts)
    max_len = max((len(t) for t in texts), default=0)
    logger.debug(
        "编码输入: texts=%d, is_query=%s, total_chars=%d, max_len=%d, instruction=%s",
        len(texts), is_query, total_chars, max_len,
        bool(_QUERY_INSTRUCTION) if is_query else "N/A",
    )

    encode_start = time.time()
    if is_query and _QUERY_INSTRUCTION:
        # 查询编码：添加 instruction 前缀
        instructed_texts = [f"{_QUERY_INSTRUCTION}{t}" for t in texts]
        vectors = model.encode(instructed_texts, normalize_embeddings=True)
        logger.debug("查询编码: 已添加 instruction 前缀 (len=%d)", len(_QUERY_INSTRUCTION))
    else:
        # 文档编码：直接编码
        vectors = model.encode(texts, normalize_embeddings=True)

    encode_elapsed_ms = (time.time() - encode_start) * 1000

    # 记录编码结果（DEBUG 级别，不记录向量内容，仅记录形状）
    shape = (len(vectors), len(vectors[0]) if len(vectors) > 0 else 0)
    logger.debug(
        "编码完成: shape=%s, dim=%d, encode_ms=%.2f",
        shape, shape[1], encode_elapsed_ms,
    )

    return vectors.tolist()


# ---------------------------------------------------------------------------
# 请求/响应模型
# ---------------------------------------------------------------------------


class EmbedRequest(BaseModel):
    """嵌入请求"""

    texts: list[str] = Field(..., description="待嵌入的文本列表", max_length=MAX_BATCH_SIZE)
    is_query: bool = Field(
        False,
        description="是否为查询文本（bge 模型会自动添加 instruction 前缀）",
    )


class EmbeddingResponse(BaseModel):
    """嵌入响应（与前端 EmbeddingResponse 接口兼容）"""

    success: bool
    vectors: list[list[float]]
    dimension: int
    modelId: str
    elapsed_ms: float


class HealthResponse(BaseModel):
    """健康检查响应"""

    status: str
    model_loaded: bool
    model_loading: bool
    model_id: str
    dimension: int
    error: Optional[str] = None


class ConfigResponse(BaseModel):
    """模型配置信息（v2.0.0 新增）"""

    model_id: str
    dimension: int
    max_tokens: int
    language: str
    description: str
    has_query_instruction: bool
    max_batch_size: int


# ---------------------------------------------------------------------------
# 路由
# ---------------------------------------------------------------------------


@app.get("/api/embed/health")
async def health() -> HealthResponse:
    """健康检查 — 返回模型加载状态"""
    if _model_load_error:
        return HealthResponse(
            status="error",
            model_loaded=False,
            model_loading=_model_loading,
            model_id=EMBEDDING_MODEL_ID,
            dimension=EMBEDDING_DIMENSION,
            error=_model_load_error,
        )
    return HealthResponse(
        status="ok" if _model is not None else "loading",
        model_loaded=_model is not None,
        model_loading=_model_loading,
        model_id=EMBEDDING_MODEL_ID,
        dimension=EMBEDDING_DIMENSION,
    )


@app.get("/api/embed/config")
async def config() -> ConfigResponse:
    """模型配置信息 — 前端可用于动态获取维度（v2.0.0 新增）"""
    return ConfigResponse(
        model_id=EMBEDDING_MODEL_ID,
        dimension=EMBEDDING_DIMENSION,
        max_tokens=_MODEL_CONFIG["max_tokens"],
        language=_MODEL_CONFIG["language"],
        description=_MODEL_CONFIG["description"],
        has_query_instruction=_QUERY_INSTRUCTION is not None,
        max_batch_size=MAX_BATCH_SIZE,
    )


@app.get("/api/embed/metrics")
async def metrics() -> dict:
    """
    运行时性能指标（v2.0.0 新增）

    返回：总请求数、平均推理时间、最近 100 个请求的 P50/P95/P99 延迟、吞吐量。
    用于性能监控和 Week 2 多 worker 优化效果验证。
    """
    return _metrics.snapshot()


@app.post("/api/embed", response_model=EmbeddingResponse)
def embed(req: EmbedRequest) -> EmbeddingResponse:
    """
    批量文本嵌入 — 返回归一化向量

    注意：使用同步 def（非 async def），uvicorn 会自动将同步路由放到线程池执行，
    避免阻塞事件循环。这是 Week 2 性能优化的关键改动。
    """
    # 生成 request_id 用于全链路追踪（8 位 hex，唯一且简短）
    request_id = uuid.uuid4().hex[:8]
    t_start = time.perf_counter()

    # 请求进入日志（DEBUG 级别，记录请求特征便于排查）
    text_lengths = [len(t) for t in req.texts] if req.texts else []
    logger.debug(
        "[req:%s] 收到嵌入请求: texts=%d, is_query=%s, max_len=%d, total_chars=%d",
        request_id, len(req.texts), req.is_query,
        max(text_lengths) if text_lengths else 0,
        sum(text_lengths),
    )

    if not req.texts:
        logger.debug("[req:%s] 空文本列表，直接返回", request_id)
        return EmbeddingResponse(
            success=True,
            vectors=[],
            dimension=EMBEDDING_DIMENSION,
            modelId=EMBEDDING_MODEL_ID,
            elapsed_ms=0,
        )

    if len(req.texts) > MAX_BATCH_SIZE:
        logger.warning(
            "[req:%s] 批量超限: %d > %d（拒绝请求）",
            request_id, len(req.texts), MAX_BATCH_SIZE,
        )
        raise HTTPException(
            status_code=400,
            detail=f"批量上限 {MAX_BATCH_SIZE}，当前 {len(req.texts)} 条，请分批请求",
        )

    # 模型获取阶段（记录耗时，区分缓存命中 vs 首次加载）
    t_model_start = time.perf_counter()
    model = get_model()  # get_model 内部有 DEBUG 日志记录缓存命中
    t_model_ms = (time.perf_counter() - t_model_start) * 1000

    # 编码阶段（_encode_with_instruction 内部有 DEBUG 日志记录编码详情）
    t_encode_start = time.perf_counter()
    vectors = _encode_with_instruction(req.texts, is_query=req.is_query)
    t_encode_ms = (time.perf_counter() - t_encode_start) * 1000

    # 总耗时（含模型获取 + 编码 + 向量序列化）
    elapsed_ms = (time.perf_counter() - t_start) * 1000
    serialize_ms = elapsed_ms - t_model_ms - t_encode_ms

    # 记录运行时指标（v2.0.0 新增）
    _metrics.record(elapsed_ms, len(req.texts))

    # 慢请求告警（超过阈值时 WARN 级别，含耗时分解便于定位瓶颈）
    if elapsed_ms > SLOW_REQUEST_THRESHOLD_MS:
        logger.warning(
            "[req:%s] 慢请求告警: %.1fms > 阈值 %.0fms | 分解: model=%.1fms, encode=%.1fms, "
            "serialize=%.1fms | texts=%d, is_query=%s, model_id=%s",
            request_id, elapsed_ms, SLOW_REQUEST_THRESHOLD_MS,
            t_model_ms, t_encode_ms, serialize_ms,
            len(req.texts), req.is_query, EMBEDDING_MODEL_ID,
        )
    else:
        # 正常请求（INFO 级别，含耗时分解）
        logger.info(
            "[req:%s] 嵌入完成: %d 条, %.1fms (model=%.1f, encode=%.1f, serialize=%.1f), "
            "dim=%d, is_query=%s",
            request_id, len(req.texts), elapsed_ms,
            t_model_ms, t_encode_ms, serialize_ms,
            EMBEDDING_DIMENSION, req.is_query,
        )

    return EmbeddingResponse(
        success=True,
        vectors=vectors,
        dimension=EMBEDDING_DIMENSION,
        modelId=EMBEDDING_MODEL_ID,
        elapsed_ms=round(elapsed_ms, 1),
    )


# ---------------------------------------------------------------------------
# 启动事件 — 可选预热
# ---------------------------------------------------------------------------

@app.on_event("startup")
async def startup_event():
    """启动事件 — 可选预热模型"""
    if WARMUP_ON_START:
        logger.info("启动预热: 正在加载模型 %s ...", EMBEDDING_MODEL_ID)
        try:
            get_model()
            logger.info("预热完成，模型已就绪")
        except Exception as e:
            logger.error("预热失败: %s", e)
    else:
        logger.info("预热未启用 (EMBEDDING_WARMUP=false)，模型将在首次请求时加载")


# ---------------------------------------------------------------------------
# 启动入口（支持 python embedding_service.py 直接运行）
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import uvicorn

    # Worker 数量（生产环境推荐 2-4，开发环境默认 1）
    workers = int(os.environ.get("UVICORN_WORKERS", "1"))

    # 自动检测 uvloop/httptools（v2.0.0 性能优化）
    # uvloop: 基于 libuv 的事件循环，比 asyncio 默认快 2-4 倍（仅 Linux/macOS）
    # httptools: C 扩展 HTTP 解析器，比 h11 快 3-5 倍（跨平台）
    loop = "auto"
    http = "auto"
    try:
        import uvloop  # noqa: F401
        loop = "uvloop"
        logger.info("检测到 uvloop，将使用其作为事件循环（性能提升 2-4 倍）")
    except ImportError:
        logger.info("uvloop 未安装（Windows 不支持），使用默认 asyncio 事件循环")

    try:
        import httptools  # noqa: F401
        http = "httptools"
        logger.info("检测到 httptools，将使用其作为 HTTP 解析器（性能提升 3-5 倍）")
    except ImportError:
        logger.info("httptools 未安装，使用默认 h11 HTTP 解析器")

    # 启动参数（可被命令行参数覆盖）
    host = os.environ.get("UVICORN_HOST", "0.0.0.0")
    port = int(os.environ.get("UVICORN_PORT", "8001"))

    logger.info(
        "启动 uvicorn: host=%s, port=%d, workers=%d, loop=%s, http=%s",
        host, port, workers, loop, http,
    )

    uvicorn.run(
        "embedding_service:app",
        host=host,
        port=port,
        workers=workers,
        loop=loop,
        http=http,
        log_level="info",
    )
