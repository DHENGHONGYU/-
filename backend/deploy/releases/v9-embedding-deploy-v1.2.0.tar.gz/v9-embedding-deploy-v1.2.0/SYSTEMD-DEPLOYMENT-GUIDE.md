# V9 Embedding Service — 生产环境单 Worker 部署指南（systemd）

> **版本**: v1.0.0
> **适用场景**: CPU 密集推理的生产环境部署
> **核心结论**: 基于 ADR-014 性能基准，CPU 场景强制 `--workers 1`

---

## 1. 设计原则

### 1.1 为什么选择单 Worker？

根据 [1w-vs-4w-performance-analysis.md](file:///d:/FinSightV9/docs/reports/1w-vs-4w-performance-analysis.md) 实测数据：

| 指标 | 1 Worker | 4 Worker | 性能优势 |
|------|----------|----------|---------|
| QPS | **90.67** | 49.03 | **+84.9%** |
| P95 延迟 | **177ms** | 325ms | **-45.5%** |
| P99 延迟 | **293ms** | 2280ms | **-87.1%** |
| 内存占用 | **20.87GB** | 22.80GB | **-8.5%** |

**根因**：sentence-transformers 推理是 CPU 密集型任务，多 worker 会导致 CPU 竞争、上下文切换开销、内存倍增。

### 1.2 扩展策略

当单 Worker 无法满足并发需求时，**选择横向扩展（多实例）而非纵向扩展（多 Worker）**：

```
推荐方案: 1 Worker × N 实例 + Nginx 负载均衡
                    ↑
            每个实例独立运行 --workers 1
            通过 Nginx 的 least_conn 策略分发请求
```

---

## 2. 环境要求

### 2.1 硬件要求

| 项目 | 最低要求 | 推荐配置 |
|------|---------|---------|
| CPU | 4 核 | 8 核+ |
| 内存 | 8GB | 16GB+ |
| 磁盘 | 10GB | 50GB+ (含模型缓存) |
| GPU | 可选 | 单卡 ≥ 16GB (GPU 场景) |

### 2.2 软件要求

| 软件 | 版本要求 | 说明 |
|------|---------|------|
| OS | Ubuntu 20.04+ / CentOS 8+ | systemd 管理 |
| Python | 3.11+ | embedding_service 运行时 |
| systemd | 230+ | 服务管理 |

---

## 3. 服务文件配置

### 3.1 完整服务文件

保存为 `/etc/systemd/system/v9-embedding.service`：

```ini
[Unit]
Description=V9 Embedding Service (Single Worker — CPU Optimized)
Documentation=https://github.com/FinSight/V9/blob/main/docs/reference/adr-014-vector-search-over-tfidf.md
After=network.target
Wants=network.target

[Service]
# ============================================================================
# 基础配置
# ============================================================================
User=embedding
Group=embedding
WorkingDirectory=/opt/finsight-v9/backend
ExecStart=/opt/finsight-v9/backend/start-embedding.sh

# ============================================================================
# 核心环境变量（基于 ADR-014 验证配置）
# ============================================================================
# —— 模型配置 ——
Environment="EMBEDDING_MODEL=all-MiniLM-L6-v2"
Environment="EMBEDDING_MAX_BATCH=64"
Environment="EMBEDDING_WARMUP=true"
Environment="EMBEDDING_SLOW_THRESHOLD_MS=500"

# —— 日志配置（生产环境 INFO，排查时 DEBUG）——
Environment="EMBEDDING_LOG_LEVEL=INFO"

# —— Uvicorn 配置（CPU 场景强制单 Worker）——
Environment="UVICORN_WORKERS=1"
Environment="UVICORN_HOST=0.0.0.0"
Environment="UVICORN_PORT=8001"

# —— HuggingFace 配置 ——
Environment="HF_HOME=/opt/finsight-v9/data/hf_cache"
Environment="HF_ENDPOINT=https://hf-mirror.com"

# —— Python 配置 ——
Environment="PYTHONUNBUFFERED=1"
Environment="PYTHONPATH=/opt/finsight-v9/backend"
Environment="TZ=Asia/Shanghai"

# ============================================================================
# 重启与可用性策略
# ============================================================================
# 崩溃后自动重启
Restart=on-failure
RestartSec=5

# 启动超时（模型预热 ~6s，预留充足时间）
TimeoutStartSec=120

# 优雅关闭（等待进行中的请求完成）
TimeoutStopSec=30

# ============================================================================
# 资源限制
# ============================================================================
# 文件描述符上限
LimitNOFILE=65536

# 进程数限制
LimitNPROC=4096

# 内存上限（根据实际调整）
MemoryMax=8G

# ============================================================================
# 日志配置
# ============================================================================
# 日志写入 journald
StandardOutput=journal
StandardError=journal
SyslogIdentifier=v9-embedding

# 日志速率限制（防止日志风暴）
LogRateLimitBurst=10000
LogRateLimitIntervalSec=60

# ============================================================================
# 安全加固
# ============================================================================
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=/opt/finsight-v9/data /var/log/v9-embedding
ProtectKernelTunables=true
ProtectKernelModules=true

[Install]
WantedBy=multi-user.target
```

### 3.2 关键参数说明

| 参数 | 推荐值 | 说明 |
|------|--------|------|
| `UVICORN_WORKERS` | **1** | CPU 密集场景强制单 Worker，GPU 场景可改为 2-4 |
| `EMBEDDING_LOG_LEVEL` | `INFO` | 生产环境 INFO，排查延迟时临时改为 DEBUG |
| `EMBEDDING_WARMUP` | `true` | 启动时预热模型，避免首次请求慢 |
| `EMBEDDING_SLOW_THRESHOLD_MS` | `500` | 超过此阈值触发 WARN 日志告警 |
| `MemoryMax` | `8G` | 防止内存泄漏导致系统 OOM |
| `Restart` | `on-failure` | 仅异常退出时重启，避免正常停止被重启 |

---

## 4. 部署步骤

### 4.1 目录结构

```
/opt/finsight-v9/
├── backend/
│   ├── embedding_service.py
│   ├── start-embedding.sh
│   ├── requirements.txt
│   └── deploy/
│       └── v9-embedding.service
├── data/
│   └── hf_cache/          # HuggingFace 模型缓存
└── logs/
    └── v9-embedding/      # 可选：独立日志文件目录
```

### 4.2 部署脚本

```bash
#!/bin/bash
# ============================================================================
# V9 Embedding Service — 生产环境一键部署脚本
# ============================================================================
set -euo pipefail

DEPLOY_DIR="/opt/finsight-v9"
SERVICE_USER="embedding"

echo "===== V9 Embedding Service 生产环境部署 ====="

# 1. 创建运行用户
if ! id "$SERVICE_USER" &>/dev/null; then
    echo "[1/6] 创建运行用户: $SERVICE_USER"
    useradd -r -s /usr/sbin/nologin "$SERVICE_USER"
fi

# 2. 创建目录
echo "[2/6] 创建目录结构"
mkdir -p "$DEPLOY_DIR"/{backend,data/hf_cache,logs/v9-embedding}

# 3. 安装 Python 依赖
echo "[3/6] 安装 Python 依赖"
cd "$DEPLOY_DIR/backend"
pip install -r requirements.txt --break-system-packages

# 4. 复制服务文件
echo "[4/6] 安装 systemd 服务"
cp deploy/v9-embedding.service /etc/systemd/system/
systemctl daemon-reload

# 5. 设置权限
echo "[5/6] 设置文件权限"
chown -R "$SERVICE_USER:$SERVICE_USER" "$DEPLOY_DIR"
chmod 750 "$DEPLOY_DIR/backend/start-embedding.sh"

# 6. 启动服务
echo "[6/6] 启动服务"
systemctl enable v9-embedding
systemctl start v9-embedding

# 等待服务就绪
sleep 30

# 验证
if systemctl is-active --quiet v9-embedding; then
    echo "✅ 部署成功！"
    echo "   服务状态: $(systemctl status v9-embedding --no-pager | head -1)"
    echo "   健康检查: curl http://localhost:8001/api/embed/health"
    echo "   性能指标: curl http://localhost:8001/api/embed/metrics"
    echo "   查看日志: journalctl -u v9-embedding -f"
else
    echo "❌ 部署失败，请检查日志:"
    journalctl -u v9-embedding --no-pager -n 50
    exit 1
fi
```

### 4.3 执行部署

```bash
# 1. 上传代码
scp -r backend/ user@server:/opt/finsight-v9/

# 2. SSH 登录服务器
ssh user@server

# 3. 执行部署脚本
cd /opt/finsight-v9/backend
bash deploy.sh
```

---

## 5. 日常运维

### 5.1 服务管理命令

```bash
# 查看服务状态
systemctl status v9-embedding

# 查看实时日志
journalctl -u v9-embedding -f

# 查看最近 100 行日志
journalctl -u v9-embedding -n 100 --no-pager

# 查看错误日志
journalctl -u v9-embedding -p err -n 50 --no-pager

# 重启服务
systemctl restart v9-embedding

# 平滑重启（零停机，等待进行中的请求完成）
systemctl kill -s HUP v9-embedding

# 停止服务
systemctl stop v9-embedding

# 开机自启
systemctl enable v9-embedding
```

### 5.2 健康检查与监控

```bash
# 基础健康检查
curl -s http://localhost:8001/api/embed/health | python -m json.tool

# 性能指标监控
curl -s http://localhost:8001/api/embed/metrics | python -m json.tool

# 模型配置检查
curl -s http://localhost:8001/api/embed/config | python -m json.tool
```

**健康检查响应示例**:

```json
{
    "status": "ok",
    "model_loaded": true,
    "model_loading": false,
    "model_id": "all-MiniLM-L6-v2",
    "dimension": 384
}
```

**性能指标响应示例**:

```json
{
    "uptime_seconds": 3600.5,
    "total_requests": 45000,
    "total_texts_embedded": 120000,
    "avg_inference_ms": 45.2,
    "recent_p50_ms": 42.1,
    "recent_p95_ms": 98.3,
    "recent_p99_ms": 156.7,
    "throughput_req_per_s": 12.5,
    "throughput_texts_per_s": 33.3
}
```

### 5.3 日志级别调整

```bash
# 临时切换到 DEBUG（排查延迟问题）
systemctl stop v9-embedding
# 编辑 /etc/systemd/system/v9-embedding.service
# 修改: Environment="EMBEDDING_LOG_LEVEL=DEBUG"
systemctl daemon-reload
systemctl start v9-embedding

# 恢复生产日志级别
# 修改回: Environment="EMBEDDING_LOG_LEVEL=INFO"
```

---

## 6. 故障排查

### 6.1 常见问题

| 问题 | 症状 | 排查命令 | 解决方案 |
|------|------|---------|---------|
| 启动失败 | 服务无法启动 | `journalctl -u v9-embedding -n 50` | 检查 Python 依赖、端口占用 |
| 模型加载慢 | 首次请求 > 10s | `curl .../metrics` 查看 avg_inference_ms | 启用 `EMBEDDING_WARMUP=true` |
| CPU 占用过高 | 持续 > 90% | `top -p $(pgrep -f uvicorn)` | 降低并发或增加实例 |
| 内存泄漏 | 持续运行后内存增长 | `free -m` 定期检查 | 调整 `MemoryMax` 或重启服务 |
| 慢请求告警 | WARN 日志频繁 | `journalctl -u v9-embedding | grep WARNING` | 分析请求特征，优化批量大小 |

### 6.2 性能诊断脚本

```bash
#!/bin/bash
# 快速诊断脚本
echo "===== V9 Embedding Service 诊断 ====="

echo "[1] 服务状态"
systemctl status v9-embedding --no-pager | head -5

echo "[2] 健康检查"
curl -s http://localhost:8001/api/embed/health 2>/dev/null || echo "服务不可用"

echo "[3] 性能指标"
curl -s http://localhost:8001/api/embed/metrics 2>/dev/null | python -m json.tool 2>/dev/null || echo "获取失败"

echo "[4] 系统资源"
echo "CPU 占用: $(top -bn1 | grep 'Cpu(s)' | awk '{print $2}' | cut -d. -f1)%"
echo "内存使用: $(free -h | awk '/^Mem:/ {print $3 "/" $2}')"

echo "[5] 最近错误"
journalctl -u v9-embedding -p err -n 5 --no-pager 2>/dev/null

echo "===== 诊断完成 ====="
```

---

## 7. 更新与升级

### 7.1 滚动更新

```bash
# 1. 上传新版本代码
scp -r backend/ user@server:/opt/finsight-v9/

# 2. 重载配置
sudo systemctl daemon-reload

# 3. 平滑重启（推荐）
sudo systemctl kill -s HUP v9-embedding
# 或完全重启
sudo systemctl restart v9-embedding

# 4. 验证
curl -s http://localhost:8001/api/embed/health
```

### 7.2 模型切换

```bash
# 编辑服务文件
sudo nano /etc/systemd/system/v9-embedding.service

# 修改模型 ID
# Environment="EMBEDDING_MODEL=bge-large-zh-v1.5"

# 重载并重启
sudo systemctl daemon-reload
sudo systemctl restart v9-embedding
```

### 7.3 GPU 切换（可选）

```bash
# 修改为 GPU 模式
sudo nano /etc/systemd/system/v9-embedding.service

# 添加/修改以下配置:
# Environment="UVICORN_WORKERS=2-4"
# Environment="CUDA_VISIBLE_DEVICES=0"
# Environment="OMP_NUM_THREADS=4"

# 重启服务
sudo systemctl daemon-reload
sudo systemctl restart v9-embedding
```

---

## 8. 附录

### 8.1 Nginx 多实例配置参考

当单 Worker 无法满足并发需求（>30 用户）时，使用 Nginx 横向扩展：

```nginx
upstream embedding_backend {
    least_conn;
    server 127.0.0.1:8001 max_fails=2 fail_timeout=10s;
    server 127.0.0.1:8002 max_fails=2 fail_timeout=10s;
    server 127.0.0.1:8003 max_fails=2 fail_timeout=10s;
}

server {
    listen 8000;
    location / {
        proxy_pass http://embedding_backend;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_next_upstream error timeout http_500 http_502 http_503;
    }
}
```

每个后端实例独立运行 `--workers 1`，端口依次为 8001、8002、8003。

### 8.2 参考文档

| 文档 | 链接 |
|------|------|
| ADR-014 向量搜索升级方案 | [adr-014-vector-search-over-tfidf.md](file:///d:/FinSightV9/docs/reference/adr-014-vector-search-over-tfidf.md) |
| 1w vs 4w 性能对比报告 | [1w-vs-4w-performance-analysis.md](file:///d:/FinSightV9/docs/reports/1w-vs-4w-performance-analysis.md) |
| systemd 服务文件 | [v9-embedding.service](file:///d:/FinSightV9/backend/deploy/v9-embedding.service) |
| Docker Compose 模板 | [docker-compose.embedding.yml](file:///d:/FinSightV9/backend/docker-compose.embedding.yml) |

---

**文档版本**: v1.0.0
**最后更新**: 2026-08-06
**维护者**: V9 Architecture Team
